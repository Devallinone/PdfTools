//
//  Walkthough1ViewController.swift
//  PDF_Tool
//
//  Created by Ritesh Kumar on 19/12/25.
//

import UIKit

class Walkthough1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func goto(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "Homwpage")
        navigationController?.pushViewController(vc!, animated: true)
    }
    
}
