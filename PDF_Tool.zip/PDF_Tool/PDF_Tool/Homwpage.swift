

import UIKit
import UniformTypeIdentifiers // Required for UTType
import QuickLook

class Homwpage: UIViewController,UITableViewDataSource,UITableViewDelegate{

  
    @IBOutlet weak var tablevieww2: UITableView!
    
    var pdfFiles: [URL] = [] // Array to store PDF file URLs
    
  

    override func viewDidLoad() {
        super.viewDidLoad()

        tablevieww2.delegate = self
        tablevieww2.dataSource = self
        
        // Load existing PDF files when view loads
        loadPDFFiles()
    }
    
    
    @IBAction func ImageToPDF(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "ImageToPDFViewController")
        navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    @IBAction func PDFmerge(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "PDFMergeViewController")
        navigationController?.pushViewController(vc!, animated: true)
    }
    
    

    @IBAction func PDFpageRemove(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "RemovePDFPageViewController") 
        navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func QRScanner(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "QrScannerViewController")
        navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    @IBAction func TextToQr(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "TextToQRViewController")
        navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    
    @IBAction func addpdffromsile(_ sender: Any) {
        // Specify PDF as the allowed content type
        let supportedTypes: [UTType] = [.pdf]
        
        // asCopy: true automatically copies the file to your app's sandbox
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = true
        
        present(documentPicker, animated: true)
    }
    
    // MARK: - Table View Data Source Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pdfFiles.count
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tablevieww2.dequeueReusableCell(withIdentifier: "PDFCell2", for: indexPath)
        let pdfURL = pdfFiles[indexPath.row]
        let fileName = pdfURL.lastPathComponent
        
        // Configure cell content
        cell.textLabel?.text = fileName
        cell.detailTextLabel?.text = getFileSizeString(for: pdfURL)
        cell.accessoryType = .disclosureIndicator
        
        // Add PDF icon to the cell
        if let pdfIcon = UIImage(systemName: "doc.fill") {
            cell.imageView?.image = pdfIcon
            cell.imageView?.tintColor = .systemRed // PDF documents are typically red
        }
        
        return cell
    }
    
    // MARK: - File Management Methods
    
    func saveSelectedPDFs(_ urls: [URL]) {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        for sourceURL in urls {
            // Get the file name from the URL
            let fileName = sourceURL.lastPathComponent
            
            // Create destination URL in documents directory
            let destinationURL = documentsDirectory.appendingPathComponent(fileName)
            
            do {
                // Check if file already exists, if so, create a unique name
                var finalDestinationURL = destinationURL
                var fileNameCounter = 1
                let fileExtension = destinationURL.pathExtension
                let baseFileName = destinationURL.deletingPathExtension().lastPathComponent
                
                while FileManager.default.fileExists(atPath: finalDestinationURL.path) {
                    let newFileName = "\(baseFileName)_\(fileNameCounter).\(fileExtension)"
                    finalDestinationURL = documentsDirectory.appendingPathComponent(newFileName)
                    fileNameCounter += 1
                }
                
                // Copy the file to documents directory
                try FileManager.default.copyItem(at: sourceURL, to: finalDestinationURL)
                print("PDF saved successfully: \(finalDestinationURL.lastPathComponent)")
                
            } catch {
                print("Error saving PDF: \(error.localizedDescription)")
            }
        }
        
        // Reload the table view after saving
        loadPDFFiles()
    }
    
    func loadPDFFiles() {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        do {
            // Get all files in documents directory
            let fileURLs = try FileManager.default.contentsOfDirectory(at: documentsDirectory, includingPropertiesForKeys: nil)
            
            // Filter only PDF files
            pdfFiles = fileURLs.filter { url in
                url.pathExtension.lowercased() == "pdf"
            }
            
            // Sort by file name for consistent display
            pdfFiles.sort { $0.lastPathComponent < $1.lastPathComponent }
            
            // Reload table view on main thread
            DispatchQueue.main.async {
                self.tablevieww2.reloadData()
            }
            
        } catch {
            print("Error loading PDF files: \(error.localizedDescription)")
        }
    }
    
    func getFileSizeString(for url: URL) -> String {
        do {
            let fileSize = try FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int64 ?? 0
            let sizeInMB = Double(fileSize) / (1024 * 1024)
            return String(format: "%.2f MB", sizeInMB)
        } catch {
            return "Unknown size"
        }
    }
    

    // Optional: Method to delete PDF files
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let pdfURL = pdfFiles[indexPath.row]
            
            do {
                try FileManager.default.removeItem(at: pdfURL)
                pdfFiles.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
            } catch {
                print("Error deleting file: \(error.localizedDescription)")
            }
        }
    }
    
    // MARK: - Table View Delegate Methods
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Deselect the row after selection
        tableView.deselectRow(at: indexPath, animated: true)
        
        // Show PDF preview
        let selectedPDFURL = pdfFiles[indexPath.row]
        showPDFPreview(for: selectedPDFURL)
    }
    
    // MARK: - PDF Preview Methods
    
    func showPDFPreview(for url: URL) {
        let previewController = QLPreviewController()
        previewController.dataSource = self
        previewController.delegate = self
        
        // Store the selected URL for the preview controller
        selectedPDFURL = url
        
        present(previewController, animated: true)
    }
    
    // Property to store the currently selected PDF URL for preview
    var selectedPDFURL: URL?
    
    // MARK: - Helper Methods
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0 // Set custom row height if needed
    }
}


extension Homwpage: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        // Ensure URLs were picked
        guard !urls.isEmpty else { return }
        
        print("Selected \(urls.count) PDF file(s)")
        
        // Save all selected PDF files
        saveSelectedPDFs(urls)
        
        dismiss(animated: true)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        dismiss(animated: true)
    }
}

// MARK: - QLPreviewControllerDataSource
extension Homwpage: QLPreviewControllerDataSource {
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return selectedPDFURL != nil ? 1 : 0
    }
    
    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        guard let url = selectedPDFURL else {
            fatalError("No PDF URL available for preview")
        }
        return url as QLPreviewItem
    }
}

// MARK: - QLPreviewControllerDelegate
extension Homwpage: QLPreviewControllerDelegate {
    func previewControllerDidDismiss(_ controller: QLPreviewController) {
        // Clear the selected URL when the preview is dismissed
        selectedPDFURL = nil
    }
}
