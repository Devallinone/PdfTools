//
//  RemovePDFPageViewController.swift
//  PDF_Tool
//
//  Created by Ritesh Kumar on 19/12/25.
//

import UIKit
import PDFKit
import UniformTypeIdentifiers
class RemovePDFPageViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    var pdfDocument: PDFDocument?
    var pdfPages: [PDFPage] = []
    var selectedpdf1: URL?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    

    private func setupUI() {

    }

    
    
    @IBAction func removePageTapped(_ sender: Any) {
        
        
        guard let document = pdfDocument, document.pageCount > 0 else {
            showAlert(title: "Error", message: "No PDF loaded or PDF is empty.")
            imageView.image = UIImage(systemName: "document.fill")
            
            return
        }
        
        let alertController = UIAlertController(title: "Remove Page",
                                              message: "Select page number to remove (1 to \(document.pageCount))",
                                              preferredStyle: .alert)
        
        alertController.addTextField { textField in
            textField.placeholder = "Page number"
            textField.keyboardType = .numberPad
        }
        
        let removeAction = UIAlertAction(title: "Remove", style: .destructive) { _ in
            if let textField = alertController.textFields?.first,
               let pageNumberText = textField.text,
               let pageNumber = Int(pageNumberText),
               pageNumber >= 1 && pageNumber <= document.pageCount {
                
                let pageIndex = pageNumber - 1
                document.removePage(at: pageIndex)
                
                // Update pdfPages array
                if pageIndex < self.pdfPages.count {
                    self.pdfPages.remove(at: pageIndex)
                }
                
                self.displayFirstPagePreview()
                self.showAlert(title: "Success", message: "Page \(pageNumber) removed successfully!")
            } else {
                self.showAlert(title: "Error", message: "Invalid page number.")
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alertController.addAction(removeAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true)
    }
    
    
    @IBAction func ShareandSavePDF(_ sender: Any) {
        guard let document = pdfDocument, document.pageCount > 0 else {
            showAlert(title: "Error", message: "No PDF to share. Please Select PDFs first.")
            
            return
        }
        
        // Save PDF to temporary directory
        let tempDirectory = FileManager.default.temporaryDirectory
        let tempURL = tempDirectory.appendingPathComponent("merged_document.pdf")
        
        do {
            let pdfData = document.dataRepresentation()
            try pdfData?.write(to: tempURL)
            
            // Create and present share sheet
            let activityViewController = UIActivityViewController(activityItems: [tempURL], applicationActivities: nil)
            
            // For iPad
            if let popoverController = activityViewController.popoverPresentationController {
                popoverController.sourceView = view
                popoverController.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 0, height: 0)
                popoverController.permittedArrowDirections = []
            }
            
            activityViewController.completionWithItemsHandler = { _, completed, _, _ in
                if completed {
                    // Clean up temporary file after sharing
                    try? FileManager.default.removeItem(at: tempURL)
                }
            }
            
            present(activityViewController, animated: true)
            
        } catch {
            showAlert(title: "Error", message: "Failed to save PDF: \(error.localizedDescription)")
        }
    }
    
    
   
    private func displayFirstPagePreview() {
        guard let document = pdfDocument, document.pageCount > 0,
              let firstPage = document.page(at: 0) else {
            imageView.image = nil
            return
        }
        
        let pageBounds = firstPage.bounds(for: .mediaBox)
        let renderer = UIGraphicsImageRenderer(size: pageBounds.size)
        
        let image = renderer.image { context in
            UIColor.white.set()
            context.fill(pageBounds)
            
            context.cgContext.translateBy(x: 0, y: pageBounds.size.height)
            context.cgContext.scaleBy(x: 1.0, y: -1.0)
            
            firstPage.draw(with: .mediaBox, to: context.cgContext)
        }
        
        imageView.image = image
    }
    
    
    private func loadPDFs() {
        // Load first PDF for initial preview
        guard let fileURL = selectedpdf1 else {
            print("PDF file 'Sample' not found in bundle.")
            // Try to show a placeholder or error state
            showPlaceholderImage()
            return
        }
        
        guard let document = PDFDocument(url: fileURL) else {
            print("Could not load PDF document.")
            showPlaceholderImage()
            return
        }
        
        pdfDocument = document
        pdfPages = []
        
        // Store all pages for removal functionality
        for pageIndex in 0..<document.pageCount {
            if let page = document.page(at: pageIndex) {
                pdfPages.append(page)
            }
        }
        
        // Display first page as preview
        displayFirstPagePreview()
        print("PDF loaded successfully. Total pages: \(document.pageCount)")
    }
    private func showPlaceholderImage() {
        // Create a placeholder image when no PDF is loaded
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 400, height: 560))
        let placeholderImage = renderer.image { context in
            UIColor.systemGray6.set()
            context.fill(CGRect(x: 0, y: 0, width: 400, height: 560))
            
            UIColor.systemGray.set()
            let text = "No PDF Loaded"
            let font = UIFont.systemFont(ofSize: 18)
            let attributes: [NSAttributedString.Key: Any] = [.font: font]
            let textSize = text.size(withAttributes: attributes)
            let textRect = CGRect(x: (400 - textSize.width) / 2, y: (560 - textSize.height) / 2, width: textSize.width, height: textSize.height)
            text.draw(in: textRect, withAttributes: attributes)
        }
        
        imageView.image = placeholderImage
    }
    
    
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    
    
    @IBAction func Selectpdf(_ sender: Any) {
        
        let supportedTypes: [UTType] = [.pdf]
      
        
        // asCopy: true automatically copies the file to your app's sandbox
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false  // Disable multiple selection
        documentPicker.modalPresentationStyle = .formSheet
        
        present(documentPicker, animated: true)
        
    }
    
    
}

extension RemovePDFPageViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        // Ensure URLs were picked
      
        
        // Save all selected PDF files
        guard !urls.isEmpty else {
               controller.dismiss(animated: true)
               return
           }
           
   
            selectedpdf1 = urls.first
     
//         firstpdfname.text = selectedpdf1!.lastPathComponent
//
//
        loadPDFs()
        dismiss(animated: true)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        dismiss(animated: true)
    }
}
