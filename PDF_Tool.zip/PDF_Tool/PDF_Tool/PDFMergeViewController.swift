//
//  PDFMergeViewController.swift
//  PDF_Tool
//
//  Created by Ritesh Kumar on 19/12/25.
//

import UIKit
import UniformTypeIdentifiers
import PDFKit

var pdfDocument: PDFDocument?
var pdfPages: [PDFPage] = []


class PDFMergeViewController: UIViewController {
    
    
    @IBOutlet weak var firstpdfname: UILabel!
    
    @IBOutlet weak var secondpdfname: UILabel!
    
    var flag = 0
    var selectedpdf1: URL?
    var selectedpdf2: URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    @IBAction func selectfirstPDF(_ sender: Any) {
        let supportedTypes: [UTType] = [.pdf]
        flag = 1
              
              // asCopy: true automatically copies the file to your app's sandbox
              let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
              documentPicker.delegate = self
              documentPicker.allowsMultipleSelection = false  // Disable multiple selection
              documentPicker.modalPresentationStyle = .formSheet
              
              present(documentPicker, animated: true)
    }
    
    @IBAction func selectSecondPDF(_ sender: Any) {
        let supportedTypes: [UTType] = [.pdf]
        flag = 2
        
        // asCopy: true automatically copies the file to your app's sandbox
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false  // Disable multiple selection
        documentPicker.modalPresentationStyle = .formSheet
        
        present(documentPicker, animated: true)
    }
    
    
    @IBAction func mergerPDF(_ sender: Any) {
        
        guard let sample1URL = selectedpdf1,
              let sample2URL = selectedpdf2 else {
            showAlert(title: "Error", message: "PDF files not found in bundle.")
            return
        }
        
        guard let pdf1 = PDFDocument(url: sample1URL),
              let pdf2 = PDFDocument(url: sample2URL) else {
            showAlert(title: "Error", message: "Could not load PDF documents.")
            return
        }
        
        // Create new PDF document
        let mergedPDF = PDFDocument()
        
        // Add pages from first PDF
        for pageIndex in 0..<pdf1.pageCount {
            if let page = pdf1.page(at: pageIndex) {
                mergedPDF.insert(page, at: mergedPDF.pageCount)
            }
        }
        
        // Add pages from second PDF
        for pageIndex in 0..<pdf2.pageCount {
            if let page = pdf2.page(at: pageIndex) {
                mergedPDF.insert(page, at: mergedPDF.pageCount)
            }
        }
        
        pdfDocument = mergedPDF
        pdfPages = []
        
        // Store all pages for removal functionality
        for pageIndex in 0..<mergedPDF.pageCount {
            if let page = mergedPDF.page(at: pageIndex) {
                pdfPages.append(page)
            }
        }
        
        // Display first page as preview
      //  displayFirstPagePreview()
        
        showAlert(title: "Success", message: "PDFs merged successfully! Total pages: \(mergedPDF.pageCount)")
    }
    
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    

    @IBAction func SaveShare(_ sender: Any) {
        guard let document = pdfDocument, document.pageCount > 0 else {
            showAlert(title: "Error", message: "No PDF to share. Please merge PDFs first.")
            return
        }
        
        // Save PDF to temporary directory
        let tempDirectory = FileManager.default.temporaryDirectory
        let tempURL = tempDirectory.appendingPathComponent("merged_document.pdf")
        
        do {
            let pdfData = document.dataRepresentation()
            try pdfData?.write(to: tempURL)
            
            // Create and present share sheet
            let activityViewController = UIActivityViewController(activityItems: [tempURL], applicationActivities: nil)
            
            // For iPad
            if let popoverController = activityViewController.popoverPresentationController {
                popoverController.sourceView = view
                popoverController.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 0, height: 0)
                popoverController.permittedArrowDirections = []
            }
            
            activityViewController.completionWithItemsHandler = { _, completed, _, _ in
                if completed {
                    // Clean up temporary file after sharing
                    try? FileManager.default.removeItem(at: tempURL)
                }
            }
            
            present(activityViewController, animated: true)
            
        } catch {
            showAlert(title: "Error", message: "Failed to save PDF: \(error.localizedDescription)")
        }
    }
    
 
    
    
    
}
extension PDFMergeViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        // Ensure URLs were picked
      
        
        // Save all selected PDF files
        guard !urls.isEmpty else {
               controller.dismiss(animated: true)
               return
           }
           
           // Store the selected PDF URL in the selectedpdf variable
        
        
        if(flag == 1)
        {
            selectedpdf1 = urls.first
     
         firstpdfname.text = selectedpdf1!.lastPathComponent
        }
        if(flag == 2)
        {
            selectedpdf2 = urls.first
     
            secondpdfname.text = selectedpdf2!.lastPathComponent
        }
        
        
        
        
      
        
        dismiss(animated: true)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        dismiss(animated: true)
    }
}
