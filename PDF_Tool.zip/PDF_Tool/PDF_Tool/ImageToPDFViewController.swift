import UIKit
import UniformTypeIdentifiers // Required for UTType
import QuickLook
import PhotosUI

class ImageToPDFViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    
    var imagee = UIImage(named: "Screenshot 2025-12-18 at 11.54.31 PM")
    var selectedImage: UIImage?
    
    
    @IBOutlet weak var imagevieww: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
     
    }
    
  
    @IBAction func selecteimageefromGallery(_ sender: Any) {
        
        checkPhotoLibraryPermission()
    }
    
    
    func convertImageToPDF() {
        guard let image = selectedImage else {
            print("Image not found")
            return
        }
        
        let pdfRenderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        
        let data = pdfRenderer.pdfData { context in
            context.beginPage()
            image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        }
        
        // Create a temporary file URL for the PDF
        let tempDirectory = FileManager.default.temporaryDirectory
        let pdfURL = tempDirectory.appendingPathComponent("convertedImage.pdf")
        
        do {
            try data.write(to: pdfURL)
            
            // Present UIActivityViewController to allow user to save/share the PDF
            let activityViewController = UIActivityViewController(activityItems: [pdfURL], applicationActivities: nil)
            present(activityViewController, animated: true, completion: nil)
        } catch {
            print("Error creating PDF: \(error)")
        }
    }
    
    
    @IBAction func SavePdf(_ sender: Any) {
        
        convertImageToPDF()
        
    }
    private func checkPhotoLibraryPermission() {
        let status = PHPhotoLibrary.authorizationStatus()
        
        switch status {
        case .authorized:
            presentImagePicker()
        case .denied, .restricted:
            showPermissionAlert()
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { [weak self] status in
                DispatchQueue.main.async {
                    if status == .authorized {
                        self?.presentImagePicker()
                    } else {
                        self?.showPermissionAlert()
                    }
                }
            }
        @unknown default:
            break
        }
    }
    
    private func presentImagePicker() {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
            showAlert(title: "Error", message: "Photo library is not available on this device.")
            return
        }
        
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
        present(imagePicker, animated: true)
    }
    
    private func showPermissionAlert() {
        let alert = UIAlertController(
            title: "Photo Library Access Required",
            message: "Please allow access to your photo library to select images.",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsUrl)
            }
        })
        
        present(alert, animated: true)
    }
    
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    // MARK: - UIImagePickerControllerDelegate Methods
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            selectedImage = image // Assign selected image to the variable
            imagevieww.image = image // Update the image view
        }
        
        picker.dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}

    



