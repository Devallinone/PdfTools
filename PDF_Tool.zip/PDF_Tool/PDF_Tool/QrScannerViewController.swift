//
//  QrScannerViewController.swift
//  PDF_Tool
//
//  Created by Ritesh Kumar on 19/12/25.
//



import UIKit
import AVFoundation
import AudioToolbox
import PhotosUI


class QrScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // MARK: - IBOutlets
    @IBOutlet weak var previewView: UIView!
    @IBOutlet weak var scanningCard: UIView!
    @IBOutlet weak var qrFrame: UIView!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var resultCard: UIView!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var flashButton: UIButton!
    @IBOutlet weak var copyButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!

    @IBOutlet weak var actionButtonsStack: UIStackView!
    @IBOutlet weak var galleryButton: UIButton!
    
    
    @IBOutlet weak var imagee: UIImageView!
    
    
    // MARK: - Properties
    var captureSession: AVCaptureSession?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var qrCodeFrameView: UIView?
    private var lastScannedCode: String?
    private var isFlashOn = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        setupCamera()
        checkCameraPermission()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Start scanning when view appears
        if let captureSession = captureSession, !captureSession.isRunning {
            captureSession.startRunning()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Stop scanning when view disappears
        if let captureSession = captureSession, captureSession.isRunning {
            captureSession.stopRunning()
        }
        
        // Turn off flash when leaving
        if isFlashOn {
            toggleFlash(nil)
        }
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        // Configure scanning card with modern styling
        scanningCard.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.95)
        scanningCard.layer.cornerRadius = 20
        scanningCard.layer.shadowColor = UIColor.black.cgColor
        scanningCard.layer.shadowOpacity = 0.1
        scanningCard.layer.shadowOffset = CGSize(width: 0, height: 4)
        scanningCard.layer.shadowRadius = 12
        
        // Configure QR frame
        qrFrame.layer.borderColor = UIColor.systemBlue.cgColor
        qrFrame.layer.borderWidth = 3
        qrFrame.layer.cornerRadius = 15
        qrFrame.backgroundColor = UIColor.clear
        
        // Configure status label
        statusLabel.text = "Position QR code within the frame"
        statusLabel.textAlignment = .center
        statusLabel.textColor = .white
        statusLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        
        // Configure result card
        resultCard.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.95)
        resultCard.layer.cornerRadius = 15
        resultCard.layer.shadowColor = UIColor.black.cgColor
        resultCard.layer.shadowOpacity = 0.1
        resultCard.layer.shadowOffset = CGSize(width: 0, height: 2)
        resultCard.layer.shadowRadius = 8
        
        // Configure result label
        resultLabel.text = "No QR code detected yet"
        resultLabel.textAlignment = .center
        resultLabel.textColor = .systemGray
        resultLabel.numberOfLines = 3
        resultLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        
        // Configure action buttons
        setupActionButtons()
        
        // Initially hide action buttons until QR code is detected
        actionButtonsStack.alpha = 0
        actionButtonsStack.isUserInteractionEnabled = false
    }
    
    private func setupActionButtons() {
        // Style buttons with rounded corners and shadows
        [flashButton, copyButton, shareButton, resetButton].forEach { button in
            button?.layer.cornerRadius = 25
            button?.layer.shadowColor = UIColor.black.cgColor
            button?.layer.shadowOpacity = 0.2
            button?.layer.shadowOffset = CGSize(width: 0, height: 2)
            button?.layer.shadowRadius = 4
        }
    }
    
    // MARK: - Camera Permission
    private func checkCameraPermission() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            // Camera access already granted
            setupCamera()
        case .notDetermined:
            // Request camera access
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    if granted {
                        self.setupCamera()
                    } else {
                        self.showCameraPermissionAlert()
                    }
                }
            }
        case .denied, .restricted:
            // Camera access denied
            showCameraPermissionAlert()
        @unknown default:
            break
        }
    }
    
    private func showCameraPermissionAlert() {
        let alert = UIAlertController(
            title: "Camera Access Required",
            message: "Please enable camera access in Settings to scan QR codes.",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in
            self.navigationController?.popViewController(animated: true)
        })
        
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsURL)
            }
        })
        
        present(alert, animated: true)
    }
    
    // MARK: - Camera Setup
    private func setupCamera() {
        // Get the default capture device
        guard let captureDevice = AVCaptureDevice.default(for: .video) else {
            print("Failed to get the camera device")
            return
        }
        
        do {
            // Get an instance of the capture device input
            let input = try AVCaptureDeviceInput(device: captureDevice)
            
            // Initialize the capture session
            captureSession = AVCaptureSession()
            captureSession?.addInput(input)
            
            // Initialize a AVCaptureMetadataOutput object
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession?.addOutput(captureMetadataOutput)
            
            // Set delegate and use the main dispatch queue
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            captureMetadataOutput.metadataObjectTypes = [.qr]
            
            // Initialize the video preview layer
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession!)
            videoPreviewLayer?.videoGravity = .resizeAspectFill
            videoPreviewLayer?.frame = previewView.layer.bounds
            
            // Add the video preview layer as a sublayer
            previewView.layer.addSublayer(videoPreviewLayer!)
            
            // Initialize the QR code frame view
            qrCodeFrameView = UIView()
            
            if let qrCodeFrameView = qrCodeFrameView {
                qrCodeFrameView.layer.borderColor = UIColor.systemGreen.cgColor
                qrCodeFrameView.layer.borderWidth = 3
                qrCodeFrameView.layer.cornerRadius = 10
                qrCodeFrameView.backgroundColor = UIColor.clear
                previewView.addSubview(qrCodeFrameView)
                previewView.bringSubviewToFront(qrCodeFrameView)
            }
            
            // Check if flash is available
            if captureDevice.hasFlash && captureDevice.isFlashAvailable {
                flashButton.isHidden = false
                flashButton.setTitle("Flash", for: .normal)
            } else {
                flashButton.isHidden = true
            }
            
            // Start running the capture session
            captureSession?.startRunning()
            
            // Configure the scanning area
            configureScanningArea()
            
        } catch {
            print("Error occurred: \(error.localizedDescription)")
            showErrorAlert(message: "Failed to setup camera: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Scanning Area Configuration
    private func configureScanningArea() {
        guard let captureSession = captureSession,
              let videoPreviewLayer = videoPreviewLayer else { return }
        
        // Define the scanning area (center area of the QR frame)
        let scanningRect = CGRect(x: 0.15, y: 0.15, width: 0.7, height: 0.7)
        let scanningRectConverted = videoPreviewLayer.metadataOutputRectConverted(fromLayerRect: previewView.bounds)
        
        // Configure the capture metadata output
        if let captureMetadataOutput = captureSession.outputs.first as? AVCaptureMetadataOutput {
            captureMetadataOutput.rectOfInterest = scanningRectConverted
        }
    }
    
    // MARK: - AVCaptureMetadataOutputObjectsDelegate
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        
        // Check if the metadataObjects array is not nil and contains at least one object
        guard metadataObjects.count > 0 else {
            qrCodeFrameView?.frame = CGRect.zero
            updateStatusMessage("Position QR code within the frame", isScanning: true)
            return
        }
        
        // Get the first metadata object
        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        
        // Check if the type of metadata object is QR code
        if metadataObj.type == .qr {
            
            // If the found metadata is equal to the QR code metadata object, update the status label and set the bounds of the QR code frame
            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
            qrCodeFrameView?.frame = barCodeObject!.bounds
            
            // Update the status label
            if metadataObj.stringValue != nil {
                
                // Check if it's a new QR code (different from last scanned)
                if metadataObj.stringValue != lastScannedCode {
                    lastScannedCode = metadataObj.stringValue
                    handleQRCodeDetected(metadataObj.stringValue!)
                }
            }
        }
    }
    
    // MARK: - QR Code Handling
    private func handleQRCodeDetected(_ code: String) {
        // Update status and show success feedback
        updateStatusMessage("QR Code Detected!", isScanning: false)
        
        // Vibrate the device to indicate successful scan
        AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
        
        // Update result label
        resultLabel.text = code
        
        // Show action buttons with animation
        showActionButtons()
        
        // Add visual feedback
        animateDetection()
        
        // Stop scanning temporarily to prevent multiple detections
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            if let captureSession = self.captureSession, captureSession.isRunning {
                captureSession.startRunning()
            }
        }
    }
    
    private func updateStatusMessage(_ message: String, isScanning: Bool) {
        statusLabel.text = message
        
        if isScanning {
            statusLabel.textColor = .white
        } else {
            statusLabel.textColor = .systemGreen
        }
    }
    
    private func showActionButtons() {
        UIView.animate(withDuration: 0.3, animations: {
            self.actionButtonsStack.alpha = 1
        }) { _ in
            self.actionButtonsStack.isUserInteractionEnabled = true
        }
    }
    
    // MARK: - Visual Feedback
    private func animateDetection() {
        // Animate the QR frame color change
        UIView.animate(withDuration: 0.2, animations: {
            self.qrCodeFrameView?.layer.borderColor = UIColor.systemGreen.cgColor
            self.qrCodeFrameView?.layer.borderWidth = 4
        }) { _ in
            UIView.animate(withDuration: 0.3) {
                self.qrCodeFrameView?.layer.borderColor = UIColor.systemBlue.cgColor
                self.qrCodeFrameView?.layer.borderWidth = 3
            }
        }
        
        // Animate the result card
        resultCard.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        UIView.animate(withDuration: 0.3) {
            self.resultCard.transform = CGAffineTransform.identity
        }
    }
    
    // MARK: - Error Handling
    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    // MARK: - Actions
    @IBAction func toggleFlash(_ sender: UIButton?) {
        guard let captureDevice = AVCaptureDevice.default(for: .video) else { return }
        
        if captureDevice.hasFlash && captureDevice.isFlashAvailable {
            do {
                try captureDevice.lockForConfiguration()
                if isFlashOn {
                    captureDevice.flashMode = .off
                    isFlashOn = false
                    flashButton.setTitle("Flash", for: .normal)
                    flashButton.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.8)
                } else {
                    captureDevice.flashMode = .on
                    isFlashOn = true
                    flashButton.setTitle("Flash On", for: .normal)
                    flashButton.backgroundColor = UIColor.systemYellow.withAlphaComponent(0.8)
                }
                captureDevice.unlockForConfiguration()
            } catch {
                print("Error controlling flash: \(error.localizedDescription)")
            }
        }
    }
    
    @IBAction func copyResult(_ sender: UIButton) {
        if let resultText = resultLabel.text, resultText != "No QR code detected yet" {
            UIPasteboard.general.string = resultText
            
            // Show feedback with animation
            copyButton.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
            UIView.animate(withDuration: 0.2, animations: {
                self.copyButton.transform = CGAffineTransform.identity
            })
            
            showFeedbackAlert(title: "Copied!", message: "QR code content copied to clipboard")
        }
    }
    
    @IBAction func shareResult(_ sender: UIButton) {
        if let resultText = resultLabel.text, resultText != "No QR code detected yet" {
            let activityViewController = UIActivityViewController(activityItems: [resultText], applicationActivities: nil)
            
            // Popover presentation for iPad
            if let popoverController = activityViewController.popoverPresentationController {
                popoverController.sourceView = shareButton
                popoverController.sourceRect = shareButton.bounds
            }
            
            present(activityViewController, animated: true)
            
            // Animate button press
            shareButton.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
            UIView.animate(withDuration: 0.2, animations: {
                self.shareButton.transform = CGAffineTransform.identity
            })
        }
    }
    

    @IBAction func selectFromGallery(_ sender: UIButton) {
        checkPhotoLibraryPermission()
    }
    
    @IBAction func resetScanner(_ sender: UIButton) {
        lastScannedCode = nil
        resultLabel.text = "No QR code detected yet"
        updateStatusMessage("Position QR code within the frame", isScanning: true)
        qrCodeFrameView?.frame = CGRect.zero
        
        // Hide action buttons
        actionButtonsStack.alpha = 0
        actionButtonsStack.isUserInteractionEnabled = false
        
        // Reset result card appearance
        resultCard.transform = CGAffineTransform.identity
        
        // Reset flash
        if isFlashOn {
            toggleFlash(nil)
        }
        
        // Animate reset button
        resetButton.transform = CGAffineTransform(rotationAngle: .pi)
        UIView.animate(withDuration: 0.3, animations: {
            self.resetButton.transform = CGAffineTransform.identity
        })
        
        // Restart scanning
        if let captureSession = captureSession, !captureSession.isRunning {
            captureSession.startRunning()
        }
        
        imagee.image = nil
    }
    
    // MARK: - Feedback

    // MARK: - Photo Library Methods
    private func checkPhotoLibraryPermission() {
        PHPhotoLibrary.requestAuthorization { status in
            DispatchQueue.main.async {
                switch status {
                case .authorized:
                    self.presentImagePicker()
                case .denied, .restricted:
                    self.showPhotoLibraryPermissionAlert()
                case .notDetermined:
                    // Shouldn't happen as we just requested
                    break
                @unknown default:
                    break
                }
            }
        }
    }
    
    private func presentImagePicker() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
        
        // Popover presentation for iPad
        if let popoverController = imagePicker.popoverPresentationController {
            popoverController.sourceView = galleryButton
            popoverController.sourceRect = galleryButton.bounds
        }
        
        
        present(imagePicker, animated: true)
    }
    
    private func showPhotoLibraryPermissionAlert() {
        let alert = UIAlertController(
            title: "Photo Library Access Required",
            message: "Please enable photo library access in Settings to select QR code images.",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsURL)
            }
        })
        
        present(alert, animated: true)
    }
    
    // MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        
        guard let selectedImage = info[.originalImage] as? UIImage
        
        else {
            
                   showErrorAlert(message: "Failed to get selected image")
            return
        }
        imagee.image = selectedImage
        // Process the image for QR codes
        processImageForQRCode(selectedImage)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
    
    private func processImageForQRCode(_ image: UIImage) {
        // Convert UIImage to CIImage for QR code detection
        guard let ciImage = CIImage(image: image) else {
            showErrorAlert(message: "Failed to process image")
            return
        }
        
        // Create QR code detector
        let detector = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: [CIDetectorAccuracy: CIDetectorAccuracyHigh])
        
        guard let features = detector?.features(in: ciImage) as? [CIQRCodeFeature] else {
            updateStatusMessage("No QR code found in selected image", isScanning: false)
            showFeedbackAlert(title: "No QR Code", message: "No QR code was detected in the selected image")
            return
        }
        
        if let qrFeature = features.first,
           let messageString = qrFeature.messageString {
            
            // QR code found!
            lastScannedCode = messageString
            handleQRCodeDetected(messageString)
            
            // Show that it was from gallery
            updateStatusMessage("QR Code found from Gallery!", isScanning: false)
        } else {
            updateStatusMessage("No QR code found in selected image", isScanning: false)
            showFeedbackAlert(title: "No QR Code", message: "No QR code was detected in the selected image")
        }
    }
    
    private func showFeedbackAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        // Style the alert to match our app theme
        alert.view.tintColor = .systemBlue
        
        // Auto-dismiss after a short delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            alert.dismiss(animated: true)
        }
        
        present(alert, animated: true)
    }
}
