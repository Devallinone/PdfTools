import UIKit
import CoreImage
import CoreImage.CIFilterBuiltins

class TextToQRViewController: UIViewController {
    
    // MARK: - UI Elements
    private let textField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Enter text to generate QR code"
        tf.borderStyle = .roundedRect
        tf.font = UIFont.systemFont(ofSize: 16)
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    private let generateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Generate QR Code", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let qrImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.backgroundColor = .systemGray6
        iv.layer.borderColor = UIColor.systemGray.cgColor
        iv.layer.borderWidth = 1
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let saveButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Save QR Code", for: .normal)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.isHidden = true
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let activityIndicator: UIActivityIndicatorView = {
        let ai = UIActivityIndicatorView(style: .large)
        ai.hidesWhenStopped = true
        ai.translatesAutoresizingMaskIntoConstraints = false
        return ai
    }()
    
    private let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    private let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private var generatedQRCode: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupConstraints()
        setupActions()
    }
    
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Text to QR Code"
        
        // Add subviews
        scrollView.addSubview(contentView)
        contentView.addSubview(textField)
        contentView.addSubview(generateButton)
        contentView.addSubview(qrImageView)
        contentView.addSubview(saveButton)
        contentView.addSubview(activityIndicator)
        view.addSubview(scrollView)
        
        // Setup keyboard handling
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            // ScrollView constraints
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            
            // ContentView constraints
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            // TextField constraints
            textField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            textField.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            textField.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 40),
            textField.heightAnchor.constraint(equalToConstant: 50),
            
            // Generate Button constraints
            generateButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            generateButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            generateButton.topAnchor.constraint(equalTo: textField.bottomAnchor, constant: 20),
            generateButton.heightAnchor.constraint(equalToConstant: 50),
            
            // QR ImageView constraints
            qrImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 40),
            qrImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -40),
            qrImageView.topAnchor.constraint(equalTo: generateButton.bottomAnchor, constant: 40),
            qrImageView.heightAnchor.constraint(equalTo: qrImageView.widthAnchor),
            
            // Save Button constraints
            saveButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            saveButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            saveButton.topAnchor.constraint(equalTo: qrImageView.bottomAnchor, constant: 20),
            saveButton.heightAnchor.constraint(equalToConstant: 50),
            
            // Activity Indicator constraints
            activityIndicator.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            
            // Content View bottom constraint
            contentView.bottomAnchor.constraint(equalTo: saveButton.bottomAnchor, constant: 40)
        ])
    }
    
    private func setupActions() {
        generateButton.addTarget(self, action: #selector(handleGenerateButtonTapped), for: .touchUpInside)
        saveButton.addTarget(self, action: #selector(saveQRCode), for: .touchUpInside)
        
        // Dismiss keyboard when tapping outside
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc private func handleGenerateButtonTapped() {
        guard let text = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !text.isEmpty else {
            showAlert(message: "Please enter some text to generate QR code")
            return
        }
        
        // Start activity indicator
        activityIndicator.startAnimating()
        generateButton.isEnabled = false
        
        // Generate QR code in background
        DispatchQueue.global(qos: .userInitiated).async {
            let qrCode = self.generateQRCode(from: text)
            
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                self.generateButton.isEnabled = true
                
                if let qrCode = qrCode {
                    self.generatedQRCode = qrCode
                    self.qrImageView.image = qrCode
                    self.saveButton.isHidden = false
                } else {
                    self.showAlert(message: "Failed to generate QR code. Please try again.")
                }
            }
        }
    }
    
    private func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: .utf8)
        
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else {
            return nil
        }
        
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("M", forKey: "inputCorrectionLevel")
        
        guard let outputImage = filter.outputImage else {
            return nil
        }
        
        let context = CIContext(options: nil)
        guard let cgImage = context.createCGImage(outputImage, from: outputImage.extent) else {
            return nil
        }
        
        let scale: CGFloat = 10
        let size = CGSize(width: outputImage.extent.size.width * scale,
                         height: outputImage.extent.size.height * scale)
        
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        defer { UIGraphicsEndImageContext() }
        
        guard let context = UIGraphicsGetCurrentContext() else {
            return nil
        }
        
        context.interpolationQuality = .none
        context.draw(cgImage, in: CGRect(origin: .zero, size: size))
        
        return UIGraphicsGetImageFromCurrentImageContext()
    }
    
    @objc private func saveQRCode() {
        guard let qrCode = generatedQRCode else {
            showAlert(message: "No QR code to save")
            return
        }
        
        UIImageWriteToSavedPhotosAlbum(qrCode, self, #selector(imageSaved(_:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    @objc private func imageSaved(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            showAlert(message: "Failed to save QR code: \(error.localizedDescription)")
        } else {
            showAlert(message: "QR code saved to Photos!", isSuccess: true)
        }
    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc private func keyboardWillShow(_ notification: Notification) {
        guard let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else {
            return
        }
        
        let keyboardHeight = keyboardFrame.height
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardHeight, right: 0)
        scrollView.contentInset = contentInsets
        scrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc private func keyboardWillHide(_ notification: Notification) {
        scrollView.contentInset = .zero
        scrollView.scrollIndicatorInsets = .zero
    }
    
    private func showAlert(message: String, isSuccess: Bool = false) {
        let alert = UIAlertController(title: isSuccess ? "Success" : "Error",
                                    message: message,
                                    preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
